const apiUrl = 'http://localhost:4444/data';

export default apiUrl;