export function dataModel() 
{
    const data = {
        "active": false,
        "text": "You can buy the premium version for $9.99",
        "url": "https://www.youtube.com/watch?v=KpsJWFuVTdI"
    };
    return data
}
